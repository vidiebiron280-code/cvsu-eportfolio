import React, { useState } from 'react';

function App() {
  // --- INTERACTIVE FEATURE 1: Form Handling & Validation ---
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formError, setFormError] = useState('');

  // --- INTERACTIVE FEATURE 2: Dynamic Project Details Display ---
  const [activeProject, setActiveProject] = useState(null);

  // --- INTERACTIVE FEATURE 3: Dynamic Layout State (Mobile Menu Toggle) ---
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Profile Information Data Object
  const profile = {
    name: "Vidie Alliesa B. Paño", 
    title: "BSIT Student / Aspiring Developer",
    vision: "CvSU Vision: The premier university in historic Cavite globally recognized for excellence in character development, global relevance, and sustainable development.",
    bio: "I am a dedicated student at Cavite State University passionate about building responsive web ecosystems and user interfaces using modern engineering tools.",
    skills: ["ReactJS", "Tailwind CSS", "JavaScript (ES6)", "HTML5 & CSS3", "Git & GitHub"],
    interests: ["Web Development", "UI/UX Design", "Open Source", "Technology Trends"]
  };

  const projects = [
    {
      id: 1,
      title: "E-Commerce Application",
      shortDesc: "A responsive online storefront prototype built with React.",
      longDesc: "This application features state persistence, interactive product filtering, and custom clean layouts configured using responsive Tailwind utility classes.",
      tech: ["ReactJS", "Tailwind CSS"]
    },
    {
      id: 2,
      title: "Student Portal Hub",
      shortDesc: "An academic records management interface dashboard.",
      longDesc: "Designed with data table displays, functional layout tabs, and clean validation states allowing straightforward educational overview tracking.",
      tech: ["ReactJS", "Tailwind CSS"]
    }
  ];

  const resume = {
    education: [
      { institution: "Cavite State University", degree: "Bachelor of Science in Information Technology", years: "2023 - Present" }
    ],
    experience: [
      { role: "Academic Project Developer", company: "Department of Information Technology", years: "Current Semester" }
    ]
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setFormError('Please fill out all fields before submitting.');
      return;
    }
    setFormError('');
    setFormSubmitted(true);
    setFormData({ name: '', email: '', message: '' });
    setTimeout(() => setFormSubmitted(false), 5000);
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans antialiased">
      
      {/* REQUIRED SECTION: Navigation Menu */}
      <nav className="bg-emerald-800 text-white sticky top-0 z-50 shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <span className="font-bold text-xl tracking-tight">{profile.name}</span>
          
          <div className="hidden md:flex space-x-6 font-medium">
            <a href="#home" className="hover:text-emerald-200 transition">Home</a>
            <a href="#about" className="hover:text-emerald-200 transition">About</a>
            <a href="#projects" className="hover:text-emerald-200 transition">Projects</a>
            <a href="#resume" className="hover:text-emerald-200 transition">Resume</a>
            <a href="#contact" className="hover:text-emerald-200 transition">Contact</a>
          </div>

          <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden focus:outline-none">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden bg-emerald-700 px-4 pt-2 pb-4 space-y-2">
            <a href="#home" onClick={() => setMobileMenuOpen(false)} className="block py-1 hover:text-emerald-200">Home</a>
            <a href="#about" onClick={() => setMobileMenuOpen(false)} className="block py-1 hover:text-emerald-200">About</a>
            <a href="#projects" onClick={() => setMobileMenuOpen(false)} className="block py-1 hover:text-emerald-200">Projects</a>
            <a href="#resume" onClick={() => setMobileMenuOpen(false)} className="block py-1 hover:text-emerald-200">Resume</a>
            <a href="#contact" onClick={() => setMobileMenuOpen(false)} className="block py-1 hover:text-emerald-200">Contact</a>
          </div>
        )}
      </nav>

      {/* REQUIRED SECTION: Home (Dashboard) */}
      <header id="home" className="bg-gradient-to-r from-emerald-800 to-teal-700 text-white py-24 px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-extrabold mb-4">Welcome to My Portfolio</h1>
          <p className="text-xl md:text-2xl font-light mb-6">Hello, I am {profile.name}, a {profile.title}.</p>
          <div className="bg-emerald-900/40 border border-emerald-500/30 p-4 rounded-xl max-w-xl mx-auto backdrop-blur-sm">
            <p className="text-xs italic tracking-wide opacity-90">{profile.vision}</p>
          </div>
          <div className="mt-8 space-x-4">
            <a href="#projects" className="inline-block bg-white text-emerald-800 font-semibold px-6 py-3 rounded-lg shadow hover:bg-emerald-50 transition">View Projects</a>
            <a href="#resume" className="inline-block bg-emerald-600 border border-emerald-400 text-white font-semibold px-6 py-3 rounded-lg shadow hover:bg-emerald-500 transition">View Resume</a>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-12 space-y-24">

        {/* REQUIRED SECTION: About Me */}
        <section id="about" className="scroll-mt-20">
          <h2 className="text-3xl font-bold border-b-4 border-emerald-600 inline-block pb-1 mb-8">About Me</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-4">
              <h3 className="text-2xl font-semibold text-emerald-800">Personal Background</h3>
              <p className="text-lg leading-relaxed text-gray-700">{profile.bio}</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
              <h3 className="text-xl font-semibold text-emerald-800 mb-4">Skills & Interests</h3>
              <div className="mb-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">Technical Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {profile.skills.map((skill, index) => (
                    <span key={index} className="bg-emerald-50 text-emerald-700 text-xs font-semibold px-3 py-1 rounded-full border border-emerald-200">{skill}</span>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">Interests</h4>
                <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                  {profile.interests.map((interest, index) => <li key={index}>{interest}</li>)}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* REQUIRED SECTION: Projects / Work Samples */}
        <section id="projects" className="scroll-mt-20">
          <h2 className="text-3xl font-bold border-b-4 border-emerald-600 inline-block pb-1 mb-8">Projects</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((proj) => (
              <div key={proj.id} className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden flex flex-col justify-between p-6 hover:shadow-md transition">
                <div>
                  <div className="w-full h-40 bg-emerald-100 rounded-lg flex items-center justify-center text-emerald-800 font-bold mb-4">
                    [ Placeholder Image for {proj.title} ]
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-gray-900">{proj.title}</h3>
                  <p className="text-gray-600 mb-4 text-sm">{proj.shortDesc}</p>
                </div>
                <div>
                  <button 
                    type="button"
                    onClick={() => setActiveProject(proj)} 
                    className="text-emerald-700 font-semibold text-sm hover:text-emerald-950 flex items-center transition"
                  >
                    View Details &rarr;
                  </button>
                </div>
              </div>
            ))}
          </div>
          {/* Conditional Rendering Modal Window for Interactive Feature 2 */}
          {activeProject && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
              <div className="bg-white max-w-lg w-full rounded-xl shadow-xl overflow-hidden p-6 relative">
                <button 
                  type="button"
                  onClick={() => setActiveProject(null)} 
                  className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 text-2xl font-bold"
                >&times;</button>
                <h3 className="text-2xl font-bold text-emerald-800 mb-2">{activeProject.title}</h3>
                <p className="text-gray-700 mb-4 text-sm leading-relaxed">{activeProject.longDesc}</p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {activeProject.tech.map((t, idx) => (
                    <span key={idx} className="bg-gray-100 text-gray-800 text-xs px-2.5 py-1 rounded font-medium">{t}</span>
                  ))}
                </div>
                <button type="button" onClick={() => setActiveProject(null)} className="w-full bg-emerald-800 text-white font-medium py-2 rounded-lg hover:bg-emerald-700 transition">Close Window</button>
              </div>
            </div>
          )}
        </section>

        {/* REQUIRED SECTION: Resume / CV */}
        <section id="resume" className="scroll-mt-20">
          <h2 className="text-3xl font-bold border-b-4 border-emerald-600 inline-block pb-1 mb-8">Resume</h2>
          <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200 grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-bold text-emerald-800 mb-4 border-b pb-2">Education</h3>
              {resume.education.map((edu, idx) => (
                <div key={idx} className="space-y-1">
                  <h4 className="font-semibold text-gray-900">{edu.degree}</h4>
                  <p className="text-sm text-gray-600">{edu.institution}</p>
                  <p className="text-xs text-emerald-600 font-medium">{edu.years}</p>
                </div>
              ))}
            </div>
            <div>
              <h3 className="text-xl font-bold text-emerald-800 mb-4 border-b pb-2">Experience</h3>
              {resume.experience.map((exp, idx) => (
                <div key={idx} className="space-y-1">
                  <h4 className="font-semibold text-gray-900">{exp.role}</h4>
                  <p className="text-sm text-gray-600">{exp.company}</p>
                  <p className="text-xs text-emerald-600 font-medium">{exp.years}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* REQUIRED SECTION: Contact Information & Form */}
        <section id="contact" className="scroll-mt-20">
          <h2 className="text-3xl font-bold border-b-4 border-emerald-600 inline-block pb-1 mb-8">Contact Information</h2>
          <div className="grid md:grid-cols-5 gap-8 items-start">
            <div className="md:col-span-2 space-y-4">
              <p className="text-gray-600">Feel free to reach out via my institutional channels or send a direct query through the functional contact form.</p>
              <div className="space-y-2 text-sm">
                <p><strong>Email:</strong> <a href="mailto:your.email@cvsu.edu.ph" className="text-emerald-700 underline">your.email@cvsu.edu.ph</a></p>
                <p><strong>GitHub:</strong> <a href="https://github.com" target="_blank" rel="noreferrer" className="text-emerald-700 underline">://github.com</a></p>
              </div>
            </div>

            {/* Interactive Form Component */}
            <div className="md:col-span-3 bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <form onSubmit={handleFormSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Full Name</label>
                  <input 
                    type="text" 
                    value={formData.name} 
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none" 
                    placeholder="Your Full Name"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Email Address</label>
                  <input 
                    type="email" 
                    value={formData.email} 
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none" 
                    placeholder="yourname@example.com"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Message</label>
                  <textarea 
                    rows="4" 
                    value={formData.message} 
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none" 
                    placeholder="Write your message here..."
                  ></textarea>
                </div>

                {formError && <p className="text-red-600 text-xs font-semibold">{formError}</p>}
                {formSubmitted && <p className="text-emerald-600 text-xs font-semibold">Thank you! Your message has been sent successfully.</p>}

                <button type="submit" className="w-full bg-emerald-800 text-white font-semibold py-2.5 rounded-lg hover:bg-emerald-700 transition">Send Message</button>
              </form>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-gray-400 text-center py-6 border-t border-gray-800 text-xs mt-24">
        &copy; {new Date().getFullYear()} {profile.name} | Built for Cavite State University (CvSU). All rights reserved.
      </footer>
    </div>
  );
}

export default App;
